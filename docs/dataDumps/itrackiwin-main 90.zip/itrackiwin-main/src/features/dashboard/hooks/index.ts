// Dashboard hooks exports
export { useLifeCategories } from '../../../hooks/useLifeCategories';
export { useOnboarding } from '../../../hooks/useOnboarding';