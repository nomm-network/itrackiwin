import { default as DynamicMetricsFormComponent } from '@/components/DynamicMetricsForm';

export default DynamicMetricsFormComponent;