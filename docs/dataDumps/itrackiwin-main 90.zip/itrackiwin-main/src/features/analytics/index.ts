// Barrel exports for analytics feature - Public API only
// When implementing analytics features, components will be exported here