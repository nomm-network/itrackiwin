// Exercises feature exports
export * from './ui';
export * from './api';
export * from './hooks';

// Export API for direct calls if needed
export { exercisesApi } from './api/exercises.api';