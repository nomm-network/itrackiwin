// Coach hooks exports
// Add AI coach-specific hooks here