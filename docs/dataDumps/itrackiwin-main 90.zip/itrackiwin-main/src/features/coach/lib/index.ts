// Coach utilities exports
// Add AI coach-specific utilities here