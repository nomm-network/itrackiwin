// Coach API exports
// AI coaching functionality will be moved here