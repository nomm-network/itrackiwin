// Gamification API exports
// Add gamification-specific API functions here