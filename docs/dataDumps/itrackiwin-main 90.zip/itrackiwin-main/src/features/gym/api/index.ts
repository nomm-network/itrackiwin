// Gym API exports
// Add gym-specific API functions here