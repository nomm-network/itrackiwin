// Gym UI components
export { default as MyGym } from '../pages/MyGym';