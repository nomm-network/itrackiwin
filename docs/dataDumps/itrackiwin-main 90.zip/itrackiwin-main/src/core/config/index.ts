// Configuration barrel exports
export * from '../../integrations/supabase/client';
export * from '../../app/providers/QueryClientProvider';