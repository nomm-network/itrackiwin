// Routing barrel exports
export * from '../../app/router/AppRoutes';
export * from '../../app/router/paths';
export * from '../../app/router/route-guards/Admin.guard';
export * from '../../app/router/route-guards/Auth.guard';