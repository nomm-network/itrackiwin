import { lazy, Suspense } from "react";
import { Routes, Route } from "react-router-dom";
import AdminLayout from "./layout/AdminLayout";
import { AdminErrorBoundary } from "@/components/util/AdminErrorBoundary";

const AdminHomePage = lazy(() => import("./pages/AdminHome.page"));
const AdminExercisesManagement = lazy(() => import("./pages/AdminExercisesManagement"));
const AdminExerciseEdit = lazy(() => import("./pages/AdminExerciseEdit.tsx"));
const AdminMusclesManagement = lazy(() => import("./pages/AdminMusclesManagement"));
const AdminEquipmentManagement = lazy(() => import("./pages/AdminEquipmentManagement"));
const AdminEquipmentEdit = lazy(() => import("./pages/AdminEquipmentEdit"));
const AdminGripsManagement = lazy(() => import("./pages/AdminGripsManagement"));

// Plate Profiles Management
const PlateProfilesPage = lazy(() => import("@/features/admin/plates/PlateProfilesPage"));
const EditPlateProfilePage = lazy(() => import("@/features/admin/plates/EditPlateProfilePage"));
const AdminMovementsManagement = lazy(() => import("./pages/AdminMovementsManagement"));
const AdminEquipmentGripCompatibility = lazy(() => import("./pages/AdminEquipmentGripCompatibility"));
const AdminTemporaryDisabled = lazy(() => import("./pages/AdminTemporaryDisabled"));
const AdminTagsAliasesManagement = lazy(() => import("./pages/AdminTagsAliasesManagement"));

const AdminTranslations = lazy(() => import("./pages/AdminTranslations"));
const AdminCategoryPage = lazy(() => import("./pages/AdminCategoryPage"));
const AdminSubcategoryPage = lazy(() => import("./pages/AdminSubcategoryPage"));
const AdminCoachLogs = lazy(() => import("./pages/AdminCoachLogs"));
const AdminAttributeSchemas = lazy(() => import("./pages/AdminAttributeSchemas"));
const AdminNamingTemplates = lazy(() => import("./pages/AdminNamingTemplates"));
const AdminSettings = lazy(() => import("./pages/AdminSettings"));
const AdminAppleSecrets = lazy(() => import("./pages/AdminAppleSecrets"));

const AdminUsersListPage = lazy(() => import("./users/AdminUsersListPage"));
const AdminUserDetailPage = lazy(() => import("./users/AdminUserDetailPage"));
const AdminMentorsListPage = lazy(() => import("@/features/mentors/admin/AdminMentorsListPage"));
const AdminMentorForm = lazy(() => import("@/features/mentors/admin/AdminMentorNew"));

// Ambassador and Battle Management
const AdminAmbassadorsPage = lazy(() => import("@/features/admin/ambassadors/AdminAmbassadorsPage"));
const AdminDealsVerifyPage = lazy(() => import("@/features/admin/ambassadors/AdminDealsVerifyPage"));
const AdminBattlesListPage = lazy(() => import("@/features/admin/battles/AdminBattlesListPage"));
const AdminBattleDetailPage = lazy(() => import("@/features/admin/battles/AdminBattleDetailPage"));
const AdminPayoutsPage = lazy(() => import("@/features/admin/ops/AdminPayoutsPage"));

export function AdminRoutes() {
  console.log('🔍 AdminRoutes component rendered!');
  return (
    <AdminErrorBoundary>
      <Suspense fallback={<div className="container py-12"><p className="text-muted-foreground">Loading admin...</p></div>}>
        <AdminLayout>
          <Routes>
            <Route index element={<AdminHomePage />} />
            <Route path="equipment" element={<AdminEquipmentManagement />} />
            <Route path="equipment/:id/edit" element={<AdminEquipmentEdit />} />
            <Route path="plates/profiles" element={<PlateProfilesPage />} />
            <Route path="plates/profiles/:id" element={<EditPlateProfilePage />} />
            <Route path="exercises" element={<AdminExercisesManagement />} />
          <Route path="exercises/:id/edit" element={<AdminExerciseEdit />} />
          <Route path="users" element={<AdminUsersListPage />} />
          <Route path="users/:id" element={<AdminUserDetailPage />} />
          <Route path="mentors" element={<AdminMentorsListPage />} />
          <Route path="mentors/new" element={
            <AdminErrorBoundary>
              <Suspense fallback={<div className="container py-6"><p className="text-muted-foreground">Loading mentor form...</p></div>}>
                <AdminMentorForm />
              </Suspense>
            </AdminErrorBoundary>
          } />
          <Route path="mentors/:id/edit" element={
            <AdminErrorBoundary>
              <Suspense fallback={<div className="container py-6"><p className="text-muted-foreground">Loading mentor form...</p></div>}>
                <AdminMentorForm />
              </Suspense>
            </AdminErrorBoundary>
          } />
          <Route path="mentors/:id" element={
            <AdminErrorBoundary>
              <Suspense fallback={<div className="container py-6"><p className="text-muted-foreground">Loading mentor details...</p></div>}>
                <AdminMentorForm />
              </Suspense>
            </AdminErrorBoundary>
          } />
      
      {/* Setup Flow Routes */}
      <Route path="setup/body-taxonomy" element={<AdminMusclesManagement />} />
      <Route path="setup/equipment" element={<AdminEquipmentManagement />} />
      <Route path="setup/grips" element={<AdminGripsManagement />} />
      <Route path="setup/equipment-grip-compatibility" element={<AdminEquipmentGripCompatibility />} />
      <Route path="setup/movement-patterns" element={<AdminMovementsManagement />} />
      <Route path="setup/tags-aliases" element={<AdminTagsAliasesManagement />} />
      
      {/* Legacy routes for backwards compatibility */}
      <Route path="muscles" element={<AdminMusclesManagement />} />
      <Route path="others/equipment" element={<AdminEquipmentManagement />} />
      <Route path="others/grips" element={<AdminGripsManagement />} />
      
      
      <Route path="attribute-schemas" element={<AdminAttributeSchemas />} />
      <Route path="naming-templates" element={<AdminNamingTemplates />} />
      <Route path="settings" element={<AdminSettings />} />
      <Route path="apple-secrets" element={<AdminAppleSecrets />} />
      <Route path="translations/*" element={<AdminTranslations />} />
          <Route path="coach-logs" element={<AdminCoachLogs />} />
          <Route path="category/:categoryId" element={<AdminCategoryPage />} />
          <Route path="category/:categoryId/sub/:subcategoryId" element={<AdminSubcategoryPage />} />
          
          {/* Ambassador and Battle Management */}
          <Route path="ambassadors" element={<AdminAmbassadorsPage />} />
          <Route path="ambassadors/deals" element={<AdminDealsVerifyPage />} />
          <Route path="battles" element={<AdminBattlesListPage />} />
          <Route path="battles/:id" element={<AdminBattleDetailPage />} />
          <Route path="payouts" element={<AdminPayoutsPage />} />
          </Routes>
        </AdminLayout>
      </Suspense>
    </AdminErrorBoundary>
  );
}