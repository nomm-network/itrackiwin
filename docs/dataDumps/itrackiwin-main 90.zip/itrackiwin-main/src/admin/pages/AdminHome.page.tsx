import { default as AdminHomeComponent } from './AdminHome.tsx';

export default AdminHomeComponent;