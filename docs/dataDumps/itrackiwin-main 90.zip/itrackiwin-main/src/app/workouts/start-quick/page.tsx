import { useStartWorkout } from '@/features/workouts';
import TrainingLauncher from '@/features/workouts/components/TrainingLauncher';

export default function StartQuickWorkoutPage() {
  return <TrainingLauncher />;
}